La memoria del ghiaccio
GeoStat Lab · Marzio De Corato

1. Estrarre l’intero archivio in una cartella.
2. Aprire R/RStudio e impostare quella cartella come directory di lavoro.
3. Installare ggplot2 se necessario: install.packages("ggplot2").
4. Consultare SOLUZIONE.txt per indizi, spiegazione dei passaggi e interpretazione.
5. Eseguire sea-ice.R. Le figure PDF e risultati.csv vengono scritti nella cartella.

La copia data.csv è il campione effettivamente utilizzato. provenance.json documenta fonti, data di acquisizione, trasformazioni, unità e limiti. I file raw conservano la risposta originale del fornitore. preview.json riporta l’ambiente R nativo e i parametri iniziali verificati.

Domanda: Quanto cambia la tendenza dell’estensione artica quando scegli marzo invece di settembre e quando restringi il periodo di osservazione?

Estensione e area sono grandezze diverse: il modello usa esclusivamente l’estensione; la colonna area è conservata per il confronto.

La selezione comprende marzo e settembre 1979–2024. Non rappresenta tutti i mesi né il volume del ghiaccio.

I residui possono essere dipendenti ed eteroschedastici. Non vengono presentati intervalli di confidenza OLS come validati né proiezioni climatiche.

Gli algoritmi e i sensori contribuiscono all’incertezza osservativa; il confronto fra periodi non attribuisce causalmente la variazione a un singolo fattore.

Il mondo dell’atlante è immaginario; il dataset contiene osservazioni reali documentate. Il campione non si aggiorna automaticamente.

Codice: PolyForm Noncommercial 1.0.0, https://polyformproject.org/licenses/noncommercial/1.0.0
Required Notice: Copyright 2026 Marzio De Corato (https://github.com/marzione00/Lab_Geo)
Dati: condizioni del fornitore in provenance.json.
