# Una singola permutazione delle etichette
# Laboratorio R autonomo; eseguire dalla radice del progetto.

# Questo blocco prepara soltanto percorsi, funzioni di servizio e riproducibilità.
# Non scarica dati, non installa pacchetti, non elimina oggetti e non modifica i CSV.
trova_radice <- function() {
  p <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
  repeat {
    if (file.exists(file.path(p, "Notebook_R_Geologia.Rproj"))) return(p)
    genitore <- dirname(p)
    if (identical(p, genitore)) stop("Aprire Notebook_R_Geologia.Rproj e riprovare.")
    p <- genitore
  }
}
root <- trova_radice()
source(file.path(root, "R", "funzioni_comuni.R"), local = TRUE)
ctx <- inizia_notebook("M06_N03")
set.seed(1011)
options(width = 100, digits = 5)
if (requireNamespace("knitr", quietly = TRUE)) {
  knitr::opts_chunk$set(echo = TRUE, error = FALSE, warning = TRUE, message = TRUE,
                       fig.width = 8, fig.height = 5, dpi = 120, fig.align = "center")
}


# Preparazione: Una domanda e un contrasto con segno
f <- leggi_dati("fossili_simulati.csv")
x <- f$diametro_tot_um[f$morfotipo=="Spiky"]
y <- f$diametro_tot_um[f$morfotipo=="Rounded"]
stopifnot(length(x)==80L,length(y)==80L,all(is.finite(c(x,y))))
delta <- mean(x)-mean(y)
data.frame(gruppo=c("Spiky","Rounded"),n=c(length(x),length(y)),
           media=c(mean(x),mean(y)),sd=c(sd(x),sd(y)))
delta


# Preparazione: Guardare le distribuzioni prima del risultato numerico
stile_grafico()
boxplot(list(Rounded=y,Spiky=x),outline=FALSE,col=c("grey90","grey85"),
        xlab="Morfotipo",ylab="Diametro totale (micrometri)",
        main="Confronto di distribuzioni, non soltanto di medie")
set.seed(611)
stripchart(list(Rounded=y,Spiky=x),vertical=TRUE,method="jitter",
           add=TRUE,pch=19,cex=.5,col=palette_geo[1:2])


# Analisi principale: Una singola permutazione delle etichette
set.seed(612)
z <- c(x,y)
nx <- length(x)
id_x <- sample(seq_along(z),size=nx,replace=FALSE)
delta_perm <- mean(z[id_x])-mean(z[-id_x])
c(osservata=delta,permutata=delta_perm)
# Ogni valore compare una volta nella partizione.
stopifnot(length(id_x)==nx,length(z[-id_x])==length(y))
